from flask import Flask, render_template, request, redirect, url_for
from flask import session

app = Flask(__name__)
app.secret_key = "1234"

brukere={

}

kunstverk = {
    "kunst1": {
        "verkbilde": "fjellet",
        "tittel": "Fjellet.",
        "kunstner": "Lars Stensli",
        "pris": "999kr",
        "bilde_url": "Fjellet.webp",
        "description": "Scenic mountain landscape.",
        "size": "80cm x 60cm"
    },
    "kunst2": {
        "tittel": "Fredrikke (Dollparts).",
        "kunstner": "Eva Sjøvold",
        "pris": "999kr",
        "bilde_url": "Fredrikke (dollparts).webp",
        "description": "Abstract representation of a figure.",
        "size": "50cm x 70cm"
    },
    "kunst3": {
        "verkbilde": "bilde",
        "tittel": "Bortførelse",
        "kunstner": "Lars Stensli",
        "pris": "999kr",
        "bilde_url": "Bortførelse.webp",
        "description": "Evocative portrayal of abduction.",
        "size": "90cm x 90cm"
    },
    "kunst4": {
        "verkbilde": "bilde",
        "tittel": "Crying",
        "kunstner": "MA$ARATI",
        "pris": "999kr",
        "bilde_url": "Crying.webp",
        "description": "Expressive depiction of sorrow.",
        "size": "70cm x 50cm"
    },
    "kunst5": {
        "verkbilde": "bilde",
        "tittel": "GIRAFF PÅ SOMMERHYTTA, MEN GLEMT Å KLIPPE GRESSET.",
        "kunstner": "DUER",
        "pris": "999kr",
        "bilde_url": "giraff_på_sommerhytta.webp",
        "description": "Whimsical scene of a giraffe at a summer cabin.",
        "size": "60cm x 80cm"
    },
    "kunst6": {
        "verkbilde": "bilde",
        "tittel": "Ilter",
        "kunstner": "NIX HAMMER",
        "pris": "999kr",
        "bilde_url": "Ilter.webp",
        "description": "Dynamic abstract composition.",
        "size": "100cm x 70cm"
    },
    "kunst7": {
        "verkbilde": "bilde",
        "tittel": "Kakkerlakkene",
        "kunstner": "MA$ARATI x BRAD",
        "pris": "999kr",
        "bilde_url": "Kakkerlakkene.webp",
        "description": "Provocative piece depicting cockroaches.",
        "size": "80cm x 60cm"
    },
    "kunst8": {
        "verkbilde": "bilde",
        "tittel": "Los Cuarentas",
        "kunstner": "DUER",
        "pris": "999kr",
        "bilde_url": "Los cuarentas.webp",
        "description": "Colorful depiction of a street scene.",
        "size": "70cm x 90cm"
    },
    "kunst9": {
        "verkbilde": "bilde",
        "tittel": "Lost Mary",
        "kunstner": "DUER",
        "pris": "999kr",
        "bilde_url": "Lost_mary.webp",
        "description": "Mysterious portrait of a woman.",
        "size": "50cm x 70cm"
    },
    "kunst10": {
        "verkbilde": "bilde",
        "tittel": "Slaget ved San Miguel",
        "kunstner": "DUER",
        "pris": "999kr",
        "bilde_url": "Slaget_ved_san.webp",
        "description": "Historical battle scene.",
        "size": "100cm x 80cm"
    },
    "kunst11": {
        "verkbilde": "bilde",
        "tittel": "Solen",
        "kunstner": "DUER",
        "pris": "999kr",
        "bilde_url": "Solen.webp",
        "description": "Radiant sun against a vibrant sky.",
        "size": "80cm x 60cm"
    },
    "kunst12": {
        "verkbilde": "bilde",
        "tittel": "Thunder Bolts n Lightning",
        "kunstner": "DUER",
        "pris": "999kr",
        "bilde_url": "Thunder_Bolts.webp",
        "description": "Energetic depiction of stormy weather.",
        "size": "90cm x 70cm"
    },
    "kunst13": {
        "verkbilde": "bilde",
        "tittel": "Atlantis",
        "kunstner": "GUTTESTREKER",
        "pris": "47250kr",
        "bilde_url": "atlantis.webp",
        "description": "Mythical underwater city.",
        "size": "120cm x 90cm"
    },
    "kunst14": {
        "verkbilde": "bilde",
        "tittel": "Systemica Epidemica",
        "kunstner": "GUTTESTREKER",
        "pris": "26250kr",
        "bilde_url": "system.webp",
        "description": "Abstract representation of a systemic epidemic.",
        "size": "80cm x 100cm"
    },
    "kunst15": {
        "verkbilde": "bilde",
        "tittel": "Sunny on a dark night",
        "kunstner": "GUTTESTREKER",
        "pris": "31 500kr",
        "bilde_url": "sunny.webp",
        "description": "Contrast of light and darkness in a scenic landscape.",
        "size": "100cm x 80cm"
    },
    "kunst16": {
        "verkbilde": "bilde",
        "tittel": "Substance city",
        "kunstner": "GUTTESTREKER",
        "pris": "999kr",
        "bilde_url": "substance.webp",
        "description": "Urban landscape with a surreal twist.",
        "size": "70cm x 50cm"
    },
    "kunst17": {
        "verkbilde": "bilde",
        "tittel": "Dogs and Angels",
        "kunstner": "BRAD",
        "pris": "25 200kr",
        "bilde_url": "DNA.webp",
        "description": "Playful depiction of dogs and celestial beings.",
        "size": "90cm x 70cm"
    },
    "kunst18": {
        "verkbilde": "bilde",
        "tittel": "Epleslang",
        "kunstner": "DUER",
        "pris": "47250kr",
        "bilde_url": "epleslang.webp",
        "description": "Surreal composition featuring intertwined apples.",
        "size": "80cm x 60cm"
    },
    "kunst19": {
        "verkbilde": "bilde",
        "tittel": "Kjeramixtape",
        "kunstner": "DUER",
        "pris": "26250kr",
        "bilde_url": "kjeramixtape.webp",
        "description": "Mixed media artwork exploring ceramic textures.",
        "size": "70cm x 50cm"
    },
    "kunst20": {
        "verkbilde": "bilde",
        "tittel": "55555",
        "kunstner": "DUER",
        "pris": "42000kr",
        "bilde_url": "555.webp",
        "description": "Abstract expression of numerical symbolism.",
        "size": "100cm x 90cm"
    }
}


@app.get("/")
def rute_forside():
    return render_template("index.html", kunstverk=kunstverk)

@app.get("/")
def forside():
    return render_template("index.html")

@app.get("/buyart")
def buyarts():
    return render_template("kunstverk.html", kunstverk = kunstverk)

@app.get("/om-oss")
def om_oss():
    return render_template("om-oss.html", kunstverk = kunstverk)

@app.get("/news")
def rute_news():
    return render_template("news.html")

@app.route("/registrer", methods=["GET", "POST"])
def registrer():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        session["username"] = username
        return redirect(url_for("index"))
    return render_template("registrer.html")


app.get("/registrert")
def rute_registrert():
    brukernavn = request.form.get("brukernavn")
    passord = request.form.get("passord")
    if brukernavn not in brukere:
        ny_bruker = {
            "passord": passord,
            "favoritter" : []
        }
        brukere[brukernavn] = ny_bruker
        logget_inn = brukernavn
        return render_template("index.html")
    else:
        return render_template("registrer.html")
    
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        if username == "admin" and password == "password":
            session["username"] = username
            return redirect(url_for("index"))
        else:
            return "Invalid username or password"
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.pop("username", None)
    return redirect(url_for("index"))

@app.get("/artdetails/<art_id>")
def art_details(art_id):
    art = kunstverk.get(art_id)
    if art:
        return render_template("art_details.html", art=kunstverk[art_id])
    else:
        return "Art piece not found", 404
    
@app.get("/artdetails")
def rute_art_details():
    return render_template("art_details.html", kunstverk = kunstverk)

@app.post("/add-to-cart")
def add_to_cart():
    art_id = request.form["art_id"]
    if "cart" not in session:
        session["cart"] = []
    if art_id not in session["cart"]:
        session["cart"].append(art_id)
    return "Added to cart!", 200

@app.get("/cart")
def cart():
    cart = session.get("cart", [])
    art_works_in_cart = [kunstverk[art_id] for art_id in cart]
    return render_template("cart.html", art_works_in_cart=art_works_in_cart)

@app.get("/checkout")
def checkout():
    return "Checkout successful!", 200

@app.route("/")
def index():
    cart_length = len(session.get("cart", []))
    return render_template("mal.html", cart_length=cart_length)

@app.post("/remove-from-cart")
def remove_from_cart():
    art_id = request.form["art_id"]
    if art_id in session["cart"]:
        session["cart"].remove(art_id)
    return "Removed from cart!", 200






app.run(debug=True)